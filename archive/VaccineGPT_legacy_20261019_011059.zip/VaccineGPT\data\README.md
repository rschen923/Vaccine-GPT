# Retained VaccineGPT data

This directory is intentionally kept in the repository because its metadata is
needed to identify and validate datasets for future work. The code snapshot is
archived separately; no data files are included in that archive.

## Metadata files

- `metadata\download_manifest.json` records download sources, paths, byte
  counts, checksums, and acquisition status.
- `metadata\file_inventory.json` records the artifact inventory and validation
  results from the data checks.
- `metadata\public_dataset_audit.json` and
  `metadata\public_self_check.json` preserve dataset audit and self-check
  reports.
- `metadata\public_training_sources_manifest_20261007.json` tracks the
  supplemental public-source archives, hashes, provenance, license status, and
  processing output for the 2026-10-07 data-preparation batch. It includes the
  T3SEpp effector-classification benchmark and AntigenDB's curated antigen
  index, paper-reported essential-target evidence from a *Streptococcus
  pneumoniae* CRISPRi-TnSeq study, and 17,109 IEDB bacterial-source antigen
  search records. These are endpoint-specific evidence, not a shared gold-label
  dataset. IEDB aggregate antigen records do not establish vaccine protection,
  and its exact data reuse terms remain to be confirmed. AntigenDB reuse is
  non-commercial under the cited database-paper license unless separately
  clarified.
- `metadata\sra_accessions.txt` preserves the SRA accession list.

The actual dataset tree remains at `..\data\` relative to the repository root.
It contains `metadata`, `processed`, `raw`, and `refseq_bacteria` directories.
Those files were left untouched; paths recorded in the metadata refer to that
retained tree.

The audit and 17 normalized JSONL outputs (399,715 records, including IEDB) for
the 2026-10-07 public-source batch are under
`..\data\processed\public_training_sources_20261007_055028\`. The raw IEDB API
pages and query manifest are under
`..\data\raw\public_training_sources\reference_databases\IEDB\`.
